#! /bin/bash
echo
line="==================================="
echo $line
echo "          Port Scanner             "
echo $line
echo
echo -n "Enter the website/IP you want to scan: "
read web
echo "Enter 1 to scan ports"
echo "Enter 2 to perform ping scan"
echo "Enter 3 to detect OS"
echo
read usr
case $usr in
1) echo -n "Enter the port(s) you would like to scan: "
read num
sudo nmap -sS -p $num $web;;
2) read -p "Please enter the amount of packets to send: " pack
ping -c$pack $web;;
3) sudo nmap -O  $web;;
esac
