#! /bin/bash
prompt_continue() {
    echo "Do you want to continue using the tool? (yes/no)"
    read continue_choice
    if [[ $continue_choice == "no" ]]; then
        echo "Exiting the Ethical Hacking Tool. Goodbye!"
        exit 0
    fi
}

# Main loop
while true; do
    echo
    line="======================================================"
    echo $line
    echo "        Welcome to Ethical Hacking Tool"
    echo "                  Designed By                "
    echo "                    Logan C                  "
    echo $line
    echo
    echo "Enter 1 to recon domains         "
    echo "Enter 2 for port scan, OS scan, ping scan"
    echo "Enter 3 to perform social engineering"
    echo "Enter 4 to perform vulnerability assessment"
    echo "Enter 5 to exit"
    echo
    read usr
    case $usr in
    1) ./dns.sh;;
    2) ./port.sh;;
    3) sudo setoolkit;;
    4) ./vuln.sh;;
    5) echo "Exiting the Ethical Hacking Tool. Goodbye!"; exit 0;;
    esac

    # Prompt for continuation after user has chosen an option
    prompt_continue
done

