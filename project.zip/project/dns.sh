#! /bin/bash
echo
line="=============================="
echo $line
echo " WELCOME TO DNS RECON MODULE  "
echo $line
echo
echo -n " Enter the domain to recon: "
read web
if [ -z $web ];then
echo "      No input detected       "
exit
fi
firefox -new-tab https://website.informer.com/$web
wget $web/robots.txt
cat robots.txt
rm robots.txt
