#! /bin/bash
echo
line="======================================================="
echo $line
echo "        Welcome to Vulnerability Assessment"
echo $line
echo
echo -n "Enter the website/domain to test for vulnerabilities: "
read web
nikto -h $web
echo
echo $line
echo "                  Scan Complete"
echo $line
